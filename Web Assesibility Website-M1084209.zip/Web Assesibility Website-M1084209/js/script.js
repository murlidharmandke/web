//getting all required element 
const searchWrapper = document.querySelector(".search-input");
const inputBox = searchWrapper.querySelector("input");
const suggBox = searchWrapper.querySelector(".autocom-box");

//if  user press any key and realese 
inputBox.onkeyup = (e) => {
        console.log(e.target.value );

}
